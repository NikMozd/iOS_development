let game = Durak()
game.delegate = DurakTracker()
for name in ["Anasteisha", "Nikolay"]{
    game.join(player: DurakPlayer(name: name))
}
game.play()
