import Foundation

public enum Suit: CaseIterable {
    case spades, hearts, diamonds, clubs
    
    public var description: String {
        switch (self) {
        case .spades: return "♠️"
        case .hearts: return "♥️"
        case .diamonds: return "♦️"
        case .clubs: return "♣️"
        }
    }
}

public enum Rank: Int, CaseIterable {
    case six = 6, seven, eight, nine, ten, jack, queen, king, ace
    
    public var descripion: String {
        switch (self) {
        case Rank.six, Rank.seven, Rank.eight, Rank.nine, Rank.ten:
            return (String)(self.rawValue)
        case Rank.jack: return "J"
        case Rank.queen: return "Q"
        case Rank.king: return "K"
        case Rank.ace: return "A"
        }
    }
}

public class Card: CustomStringConvertible, Hashable {
    public var rank: Rank
    public var suit: Suit
    
    public init(rank: Rank, suit: Suit) {
        self.rank = rank
        self.suit = suit
    }
    
    public var description: String {
        return self.rank.descripion + self.suit.description
    }
    
    public static func == (lhs: Card, rhs: Card) -> Bool {
        return lhs.rank == rhs.rank && lhs.suit == rhs.suit
    }
    
    public func hash(into hasher: inout Hasher) {
        hasher.combine(rank)
        hasher.combine(suit)
    }
}
