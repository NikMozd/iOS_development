import Foundation

public protocol Player {
    var name: String { get }
    var cards: Set<Card> { get set }
}

public enum PlayerAction {
    case win
    case attack(target: Player, card: Card)
    case beat(toBeat: Card, tool: Card)
    case take(card: Card)
    case loose
}
