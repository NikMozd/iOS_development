import Foundation

public class DurakPlayer: Player {
    public let name: String
    public var cards: Set<Card>
    
    public init(name: String) {
        self.name = name
        cards = []
    }
}

public class DurakTracker: DurakDelegate {
    public init(){}
    
    public func gameDidStartTurn(_ game: TurnbasedGame) {
        print("===-===-===")
    }

    public func playerDidStartTurn(_ player: Player) {
        print("\(player.name) starts his\\her turn")
    }
}
