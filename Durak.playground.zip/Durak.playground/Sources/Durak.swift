import Foundation

public protocol DurakDelegate: MultiplayerTurnbasedGameDelegate, CardGameDelegate {}

public class Durak: CardGame, MultiplayerGame, TurnbasedGame {
    public let name = "Durak (without throw-in & transfers)"
    var cards: [Card]
    var trumpSuit: Suit
    
    public var delegate: DurakDelegate?
    
    public init() {
        cards = []
        for rank in Rank.allCases {
            for suit in Suit.allCases {
                cards.append(Card(rank: rank, suit: suit))
            }
        }
        cards.shuffle()
        trumpSuit = cards.last!.suit
    }
    
    // MARK: - CardGame
    public let cardsPerPlayer = 6
    
    // MARK: - MultyplayerGame

    public var players: [Player] = [DurakPlayer]()

    public func join (player: Player) {
        players.append(player)
        delegate?.player(player, didJoinTheGame: self)
    }
    
    // MARK: - TurnbasedGame
    
    private var numberOfTurns = 0
    private var currentPlayerIndex = 0

    public var turns: Int {
        get { return numberOfTurns }
    }

    public var hasEnded: Bool {
        get {
            return players.count == 0
                || players.filter({p in p.cards.count != 0}).count <= 1
        }
    }

    public func start() {
        for i in 0..<players.count {
            players[i].cards = Set<Card>(cards.prefix(upTo: cardsPerPlayer))
            cards = Array(cards.suffix(from: cardsPerPlayer))
        }
        currentPlayerIndex = 0
        delegate?.gameDidStart(self)
        print("Trump suit is \(trumpSuit.description)")
    }

    public func end() {
        for player in players.filter({p in p.cards.count == 0}) {
            delegate?.player(player, didTakeAction: .win)
        }
        for player in players.filter({p in p.cards.count != 0}) {
            delegate?.player(player, didTakeAction: .loose)
        }
        delegate?.gameDidEnd(self)
    }

    public func makeTurn() {
        numberOfTurns += 1
        delegate?.gameDidStartTurn(self)
        
        while (players[currentPlayerIndex % players.count].cards.count == 0) {
            currentPlayerIndex += 1
        }
        var attacker = players[currentPlayerIndex % players.count]
        currentPlayerIndex += 1
        while (players[currentPlayerIndex % players.count].cards.count == 0) {
            currentPlayerIndex += 1
        }
        var defender = players[currentPlayerIndex % players.count]
        
        playerMakeTurn(&attacker, &defender)
        delegate?.gameDidEndTurn(self)
    }
    
    // MARK: - Player logic

    public func playerMakeTurn( _ attacker: inout Player, _ defender: inout Player) {
        delegate?.playerDidStartTurn(attacker)
        delegate?.game(self, didPlayerPlays: attacker)
        delegate?.game(self, didPlayerPlays: defender)
        
        let cardToBeat = attacker.cards.shuffled().first!
        delegate?.player(attacker, didTakeAction: .attack(target: defender, card: cardToBeat))
        
        let cardBeating = defender.cards.first(where: {card in beats(card, cardToBeat)})
        if (cardBeating != nil) {
            delegate?.player(defender, didTakeAction: .beat(toBeat: cardToBeat, tool: cardBeating!))
            
            attacker.cards.remove(cardToBeat)
            defender.cards.remove(cardBeating!)
            
            if (cards.count > 0) {
                attacker.cards.insert(cards[0])
                cards.remove(at: 0)
            }
            if (cards.count > 0) {
                defender.cards.insert(cards[0])
                cards.remove(at: 0)
            }
        } else {
            delegate?.player(defender, didTakeAction: .take(card: cardToBeat))
            
            attacker.cards.remove(cardToBeat)
            defender.cards.insert(cardToBeat)
            
            if (cards.count > 0) {
                attacker.cards.insert(cards[0])
                cards.remove(at: 0)
            }
            
            currentPlayerIndex += 1
        }
        
        delegate?.playerDidEndTurn(attacker)
    }
    
    public func beats(_ card: Card, _ another: Card) -> Bool {
        return (card.suit == trumpSuit && another.suit != trumpSuit)
            || (card.suit == another.suit && card.rank.rawValue > another.rank.rawValue)
    }
}
