import Foundation

// Game

public protocol CardGame: Game {
    var cardsPerPlayer: Int { get }
}

// Delegates

public protocol CardGameDelegate: GameDelegate {
    func game(_ game: CardGame, didPlayerPlays player: Player)
}

// Default Implementation

extension CardGameDelegate {
    public func game(_ game: CardGame, didPlayerPlays player: Player) {
        print("\(player.name) has cards: \(player.cards)")
    }
}
